#' Check table name
#'
#' Check X-13ARIMA-SEATS table name so that the B1 table can be extracted when 
#' no prior adjustment is done with the \code{seasonal} package
#' \insertCite{seasonal2018}{blsplotGG}. 
#'
#' Version 1.1, 2026-04-17
#'
#' @param seas_obj \code{seas} object for a single series.
#'        \code{seasonal} package \insertCite{seasonal2018}{blsplotGG}.
#'        This is a required entry.
#' @param this_series Character string; a table name or abbreviation from 
#'        X-13ARIMA-SEATS.
#' @param to_upper Logical scalar; return table name that is uppercase.
#'        Default is \code{FALSE}.
#' @return Character string; an X-13ARIMA-SEATS table name. If the table is 
#'         \code{"b1"} or \code{"adjoriginal"}, this function will return
#'         \code{"a1"}.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' air_seas_short <- 
#'    seasonal::seas(AirPassengers, 
#'                   series.span = ',1960.9', 
#'                   transform.function = "log", 
#'                   arima.model="(0 1 1)(0 1 1)",
#'                   forecast.maxlead = 36, 
#'                   x11 = "", 
#'                   series.save = "b1",
#'                   slidingspans = "")
#' this_series <- 
#'     check_table(air_seas_short, "b1") 
#' @importFrom Rdpack reprompt
#' @export
check_table <- 
	function(seas_obj = NULL, this_series = NULL, to_upper = FALSE) {
    # Author: Brian C. Monsell (OEUS) Version 1.1, 2026-04-17

    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        stop("must specify a seas object")
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
            stop("First argument must be a seas object")
        }
    }
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(this_series)) {
        stop("must specify a this_series argument")
    } 
	
    # Check if this_series is b1 or adjoriginal
	if (sum(c("b1", "adjoriginal") %in% tolower(this_series) > 0)) {
	# If the b1 table is not saved, change table name to a1.
		obj_series <- tolower(names(seas_obj$series))
	    if (sum(obj_series %in% tolower(this_series)) < 1) {
		   this_series <- "a1"
		}
	}
    
	if (to_upper) { this_series <- to_upper(this_series) }
	
	return(this_series)
}
