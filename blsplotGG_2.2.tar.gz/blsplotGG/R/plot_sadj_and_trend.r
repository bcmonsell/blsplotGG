#' Plot X-13 seasonal adjustment, trend on same axis
#'
#' Generates a \code{ggplot} object with a time series plot that compares an X-13 
#' seasonal adjustment and trend, extracted from a \code{seas} object. 
#' The plot optionally includes the original series.
#'
#' Version 3.5, 2/17/2026
#'
#' @param seas_obj \code{seas} object generated from a call of \code{seas} on a single time series
#'        This is a required entry.
#' @param plot_ori Logical scalar, indicates if original series is included with plot. 
#'        Default is \code{TRUE}.
#' @param main_title Title for the plot. 
#'        By default, the routine will generate a trend based on the 
#'        type of adjustment (X-11 and SEATS) done.
#' @param sub_title Subtitle for the plot. Optional entry.
#' @param this_x_label Label for X-axis.  Default is \code{"Time"}
#' @param this_y_label Label for Y-axis.  Default is \code{" "}
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. 
#'        Default is no grid lines. 
#' @param do_background Logical scalar; indicates grey background included in plot.
#'        Default is no grey background;
#' @param line_color Character vector of length 2 (if \code{plot_ori} is \code{FALSE})
#'        or 3 (if \code{plot_ori} is \code{TRUE}); color used for lines in the plot,
#'        in the order of original series (if specified), seasonally adjusted series, trend. 
#'        Default is generated from the \code{RColorBrewer} palette \code{"Dark2"}.
#'        For a listing of R color codes, 
#'        see \insertCite{rchartsColors;textual}{blsplotGG}.
#' @param this_palette Character string; default \code{RColorBrewer} palette \insertCite{RColorBrewer}{blsplotGG}.
#'        Deault is \code{"Dark2"}.
#' @param line_label Caracter vector of length 2; labels used for lines in the plot,
#'        in the order of original series, seasonally adjusted series. 
#'        Default is \code{c("Ori", "SA", "Trend")} (if original series plotted) or
#'        \code{c("SA", "Trend")}.
#' @param this_legend_title Title for legend.  Default is \code{"Series"}
#' @param this_legend_title_size integer scalar; Size of the legend title.
#'        Default is \code{12}.
#' @param this_legend_text_size integer scalar; Size of the legend title.
#'        Default is \code{10}.
#' @param this_legend_position character String; The position of the legend, which can be one of
#'        \code{top}, \code{bottom}, \code{left}, \code{right}.
#'        Default is \code{right}.
#' @param this_legend_space integer scalar; Space between legend and plot in points.
#'        Default is \code{10}.
#' @return A \code{ggplot} object that generates a plot comparing a 
#'         seasonally adjusted series with the trend generated from the same
#'         X-13ARIMA-SEATS seasonal adjustment.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' ukgas_x11_seas   <- 
#'    seasonal::seas(UKgas, series.period = 4, arima.model = "(0 1 1)(0 1 1)", 
#'                   transform.function = "log", forecast.maxlead = 20,
#'                   x11.seasonalma = "s3x5", x11.save = "d12",
#'                   check.print = c( 'pacf', 'pacfplot' ))
#' ukgas_x11_sadj_and_trend_p <- 
#'     plot_sadj_and_trend(ukgas_x11_seas, plot_ori = TRUE,
#'                         main_title = "UK Gas",
#'                         sub_title = "X-11 Seasonal Adjustment",
#'                         line_color = c("lightgrey", "steelblue", "forestgreen"))
#' ukgas_seats_seas <- 
#'    seasonal::seas(UKgas, series.period = 4, arima.model = "(0 1 1)(0 1 1)", 
#'                   transform.function = "log", forecast.maxlead = 20,
#'                   seats.save = "s12",
#'                   check.print = c( 'pacf', 'pacfplot' ))
#' ukgas_seats_sadj_and_trend_p <- 
#'     plot_sadj_and_trend(ukgas_seats_seas, plot_ori = FALSE, 
#'                         main_title = "UK Gas Series",
#'                         sub_title = "SEATS Seasonal Adjustment",
#'                         line_color = c("steelblue", "forestgreen"))
#' @importFrom rlang .data
#' @importFrom magrittr %>%
#' @importFrom Rdpack reprompt
#' @export
plot_sadj_and_trend <- 
    function(seas_obj = NULL, 
             plot_ori = TRUE, 
             main_title = NULL, 
             sub_title = NULL, 
             this_x_label = "Time", 
             this_y_label = " ", 
             do_grid = FALSE,
             do_background = FALSE,
             line_color = NULL, 
             this_palette = "Dark2",
             line_label = NULL,
             this_legend_title = "Series",
			 this_legend_title_size = 12,
			 this_legend_text_size = 10,
			 this_legend_position = "right",
			 this_legend_space = 10) {
    # Author: Brian C. Monsell (OEUS) Version 3.5, 2/17/2026

    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        cat("must specify a seas object")
		return(NULL)
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
            cat("First argument must be a seas object")
			return(NULL)
        }
    }

	this_sadj  <- seasonal::final(seas_obj)
	this_trend <- seasonal::trend(seas_obj)
	if (plot_ori) {
		this_ori <- seasonal::original(seas_obj)
		if (length(this_ori) > length(this_sadj)) {
		  this_start <- start(this_sadj)
		  this_end <- end(this_sadj)
		  this_frequency <- frequency(this_sadj)
		  this_ori <- 
		    window(start = this_start, end = this_sadj, frequency = this_frequency)
		}
	}
	
	if ("seatsadj" %in% names(seasonal::udg(seas_obj))) {
		this_sa_type <- "SEATS"
	} else {
		this_sa_type <- "X-11"
	}
	
	if (is.null(main_title)) {
		main_title <- 
			paste0(this_sa_type, " Seasonal Adjutment and Trend")
	}
	
	# check legend options 
	position_all <- c("top", "bottom", "left", "right")
	if(sum(match(position_all, this_legend_position), na.rm = TRUE) == 0) {
        cat(paste("Legend position choice not valid:", this_legend_position))
		return(NULL)
	}
	
	if(this_legend_text_size <= 0) {
        cat(paste("Legend text size not valid (must be greater than zero):", 
		           this_legend_text_size))
		return(NULL)
	}
	
	if(this_legend_title_size <= 0) {
        cat(paste("Legend title text size not valid (must be greater than zero):", 
		           this_legend_title_size))
		return(NULL)
	}
    
    num_color <- 3
    if (!plot_ori) {
		num_color <- 2
		if (is.null(line_label)) { 
			line_label <- c("SA", "Trend")
		}
    } else {
		if (is.null(line_label)) { 
			line_label <- c("Ori", "SA", "Trend")
		}
	}
	
    if (is.null(line_color)) {
        line_color <- RColorBrewer::brewer.pal(3, this_palette)[1:num_color]
    } else {
        if (length(line_color) < num_color) {
	    if (length(line_color) > 1) {
                warning("Number of line colors specified less than series plotted.")
                warning("Will use colorRampPalette to increase number of colors.")
                line_color <- grDevices::colorRampPalette(line_color)(num_color)
            }
        }
    }

    if (!plot_ori) {
        this_df <- 
			data.frame(date = tsbox::ts_df(this_sadj)$time, 
				sadj = as.double(this_sadj), 
				trend = as.double(this_trend)) %>%
				dplyr::select(.data$date, .data$sadj, .data$trend) %>%
				tidyr::gather(key = "comp", value = "value", -date)
        p_sadj_trend <- 
            ggplot2::ggplot(this_df) + 
            ggplot2::geom_line(ggplot2::aes(x = .data$date, 
                                            y = .data$value, 
                                            color = .data$comp)) + 
            ggplot2::scale_color_manual(labels = line_label, 
                                        values = line_color) +
            ggplot2::labs(title = main_title,
                          subtitle = sub_title,
                          x = this_x_label,
                          y = this_y_label)
    } else {
        this_df <- 
            data.frame(date = tsbox::ts_df(this_sadj)$time, 
	            ori = as.double(this_ori),  
				sadj = as.double(this_sadj), 
				trend = as.double(this_trend)) %>%
	        dplyr::select(.data$date, .data$ori, .data$sadj, .data$trend) %>%
			tidyr::gather(key = "comp", value = "value", -date)
        
        p_sadj_trend <- 
            ggplot2::ggplot(this_df) + 
            ggplot2::geom_line(ggplot2::aes(x = .data$date, 
                                            y = .data$value, 
                                            color = .data$comp)) + 
            ggplot2::scale_color_manual(labels = line_label, 
                                        values = line_color) +
            ggplot2::labs(title = main_title,
                          subtitle = sub_title,
                          x = this_x_label,
                          y = this_y_label)
    }
    
    p_sadj_trend <- 
		p_sadj_trend + 
			ggplot2::guides(color = ggplot2::guide_legend(this_legend_title))
	
	# remove grey background if \code{do_background = FALSE} 
    if (!do_background) {
		p_sadj_trend <- p_sadj_trend + ggplot2::theme_bw()
    }

	# remove grid lines if \code{do_grid = FALSE}
	if (!do_grid) {
	    p_sadj_trend <- p_sadj_trend + 
		    ggplot2::theme(panel.grid.major = ggplot2::element_blank(), 
			               panel.grid.minor = ggplot2::element_blank())
	}

	p_sadj_trend <- p_sadj_trend +
		ggplot2::theme(legend.text = ggplot2::element_text(size = this_legend_text_size),
		               legend.title = ggplot2::element_text(size = this_legend_title_size),
					   legend.position = this_legend_position,
					   legend.box.spacing = ggplot2::unit(this_legend_space, "pt"))
       
	return(p_sadj_trend)
}
