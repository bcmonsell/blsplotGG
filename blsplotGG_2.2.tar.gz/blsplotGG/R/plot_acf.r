#' Generate ACF plot of the regARIMA model residuals.
#'
#' Generate ACF, PACF, or squared ACF plot of the regARIMA model residuals using a \code{seas} object as input.
#' 
#' Version 5.1, 12/30/2025
#'
#' @param seas_obj \code{seas} object generated from a call of \code{seas} on a single time series
#'        This is a required entry.
#' @param this_plot Character string; three character code for the type of plot to be generated.
#'        Allowed entries are \code{"acf"} (sample autocorrelation function, default), 
#'             \code{"pcf"} (sample partial autocorrelation function), 
#'             \code{"ac2"} (squared autocorrelation function).
#' @param acf_range Range of values you wish the acf plot to be plotted over. 
#'        Default is range of the series.
#' @param add_ci Logical scalar; indicates if confidence intervals are added to the plot.
#'        Default is confidence intervals are added. 
#' @param main_title Title for the plot. 
#'        Default is generated based on the value of \code{this_plot}.
#' @param sub_title Subtitle for the plot. Default is \code{NULL}, or no subtitle.
#' @param this_x_label Label for X axis. Default is \code{"Lags"}.
#' @param this_y_label Label for Y axis. 
#'        Default is generated based on the value of \code{this_plot}.
#' @param this_x_axis_breaks Numeric vector; sets the values for the x-axis.
#'        Default uses the value of \code{this_frequency} to set x-axis.
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines.
#'        Default is no grid lines. 
#' @param do_background Logical scalar; indicates grey background included in plot.
#'        Default is no grey background;
#' @param acf_color Color used for lines in ACF plot.  
#'        Default is \code{"steelblue"}.
#' @param ci_color Color used for confidence interval in ACF plot.  
#'        Default is \code{"grey"}.
#' @return A \code{ggplot} object that produces an ACF, PACF, or squared ACF plot
#'         of the regARIMA residuals.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @examples
#' ukgas_x11_seas <- 
#'    seasonal::seas(UKgas, series.period = 4, 
#'                   arima.model = "(0 1 1)(0 1 1)", 
#'                   transform.function = "log", 
#'                   forecast.maxlead = 20,
#'                   x11.seasonalma = "s3x5", 
#'                   check.print = c( 'pacf', 'pacfplot' ),
#'                   check.maxlag = 12,
#'                   check.save = c("acf", "pcf", "ac2"))
#' p_ukgas_acf   <- 
#'    plot_acf(ukgas_x11_seas, this_plot = "acf",
#'             main_title = "UK Gas Model Residual ACF",
#'             acf_color = "darkblue")
#' p_ukgas_pacf   <- 
#'    plot_acf(ukgas_x11_seas, this_plot = "pcf",
#'             main_title = "UK Gas Model Residual PACF",
#'             acf_color = "darkblue")
#' p_ukgas_acf2   <- 
#'    plot_acf(ukgas_x11_seas, this_plot = "ac2",
#'             main_title = "UK Gas Model Squared ACF",
#'             acf_color = "darkblue")
#' @export
plot_acf <- 
	function(seas_obj = NULL,
			 this_plot = "acf",
			 acf_range = NULL,
			 add_ci = TRUE, 
			 main_title = "ACF Plot",
			 sub_title = NULL, 
			 this_x_label = "Lag",
			 this_y_label = "ACF", 
			 this_x_axis_breaks = NULL,
			 do_grid = FALSE,
			 do_background = FALSE,			 
			 acf_color = "steelblue",
			 ci_color = "grey") {
    # Author: Brian C. Monsell (OEUS) Version 5.1, 12/30/2025
 
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        cat("must specify a seas object")
		return(NULL)
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
            cat("First argument must be a seas object")
			return(NULL)
        }
    }

    acf_type_all <- c("acf", "pcf", "ac2")
	if(sum(match(acf_type_all, this_plot), na.rm = TRUE) == 0) {
        cat(paste("ACF plot type not valid:", this_plot))
		return(NULL)
	}
	
	this_matrix <- seasonal::series(seas_obj, this_plot)
	if (add_ci) {
		this_acflimit <- seasonal::udg(seas_obj, "acflimit")
	}
	
	this_freq <- seasonal::udg(seas_obj, "freq")
	
	if (is.null(main_title)) {
		if (this_plot == "acf") {
			main_title <- "ACF Plot"
		} else {
			if (this_plot == "pcf") {
				main_title <- "PACF Plot"
			} else {
				main_title <- "Squared ACF Plot"
			}
		}
	}
	
	if (is.null(this_y_label)) {
		if (this_plot == "acf") {
			this_y_label <- "ACF"
		} else {
			if (this_plot == "pcf") {
				this_y_label <- "PACF"
			} else {
				this_y_label <- "ACF2"
			}
		}
	}
	
#	generate ggplot object for acf plot
	p_acf <- 
		plot_acf_matrix(acf_matrix = this_matrix, 
		                acf_range = acf_range,
						add_ci = add_ci,
						acflimit = this_acflimit,
						main_title = main_title,
						sub_title = sub_title,
						this_x_label = this_x_label,
						this_y_label = this_y_label,
						this_frequency = this_freq,
						this_x_axis_breaks = this_x_axis_breaks,
						acf_color = acf_color,
						ci_color = ci_color)
						
	# remove grey background if \code{do_background = FALSE} 
    if (!do_background) {
		p_acf <- p_acf + ggplot2::theme_bw()
    }

	# remove grid lines if \code{do_grid = FALSE}
	if (!do_grid) {
	    p_acf <- p_acf + 
		    ggplot2::theme(panel.grid.major = ggplot2::element_blank(), 
			               panel.grid.minor = ggplot2::element_blank())
	}
       
	return(p_acf)
}
