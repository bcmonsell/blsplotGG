#' Final t-statistics for the outlier identification procedure plot
#'
#' Generates a plot of the final t-statistics for the outlier identification procedure.
#' A description of the outlier identification procedure is given in the documentation of the 
#' \code{outlier} spec in \insertCite{@Section 7.11 of of @Census2025;textual}{blsplotGG},
#' with more details in \insertCite{@Appendix B of @Findley98;textual}{blsplotGG}.
#'
#' Version 6.3, 2/10/2026
#' 
#' @param seas_obj \code{seas} object generated from a call of \code{seas} on a single time series
#'                  This is a requited entry.
#' @param start_plot Integer vector of length 2; Starting date for plot. Default is starting date for the time series. 
#' @param main_title Character string; main title of plot.  Default is  \code{'Outlier T-Values'}.
#' @param this_y_label Character string; y-axis label for plot, if specified.
#' @param this_x_label Label for X axis. Default is \code{"Time"}.
#' @param add_identified_outliers Logical scalar; indicates if outlier plots will include identified outliers. 
#'                                Default is not including identified outliers. 
#' @param do_grid Logical scalar; indicates if certain plots will have grid lines. 
#'        Default is no grid lines. 
#' @param do_background Logical scalar; indicates grey background included in plot.
#'        Default is no grey background;
#' @param color_otl Character array of length 3; color used for different outliers, with the order being \code{'ao','ls','tc'}. 
#'        Default is NULL.
#' @param this_palette Character string; default \code{RColorBrewer} palette \insertCite{RColorBrewer}{blsplotGG}.
#'        Deault is \code{"Dark2"}.
#' @param this_legend_title Title for legend.  Default is \code{"Year"}.
#' @param this_legend_title_size integer scalar; Size of the legend title.
#'        Default is \code{12}.
#' @param this_legend_text_size integer scalar; Size of the legend title.
#'        Default is \code{10}.
#' @param this_legend_position character String; The position of the legend, which can be one of
#'        \code{top}, \code{bottom}, \code{left}, \code{right}.
#'        Default is \code{right}.
#' @param this_legend_space integer scalar; Space between legend and plot in points.
#'        Default is \code{10}.
#' @return A \code{ggplot} object which produces a plot of the final t-statistics 
#'         from the automatic outlier identification procedure.
#'
#' @author Brian C. Monsell, \email{monsell.brian@@bls.gov} or \email{bcmonsell@@gmail.com}
#'
#' @references
#'  \insertAllCited{}
#'
#' @examples
#' air_seas_outlier <- 
#'     seasonal::seas(AirPassengers, arima.model = "(0 1 1)(0 1 1)", 
#'                    outlier.save = "fts", outlier.types = "all")
#' plot_fts_air <- 
#'     plot_fts(air_seas_outlier, 
#'              main_title = "Outlier T-Values for Airline Passengers")
#' plot_fts_air_add_id_otl <- 
#'     plot_fts(air_seas_outlier, 
#'              main_title = "Outlier T-Values for Airline Passengers",
#'              add_identified_outliers = TRUE)
#' @importFrom magrittr %>%
#' @importFrom rlang .data 
#' @importFrom Rdpack reprompt
#' @export
plot_fts <- 
	function(seas_obj = NULL, 
			 start_plot = NULL, 
			 main_title = "Outlier T-Values", 
	         this_y_label = NULL, 
			 this_x_label = "Time", 
			 add_identified_outliers = FALSE, 
			 do_grid = FALSE, 
             do_background = FALSE, 
	         color_otl = NULL, 
			 this_palette = "Dark2", 
			 this_legend_title = "Outlier",
			 this_legend_title_size = 12,
			 this_legend_text_size = 10,
			 this_legend_position = "right",
			 this_legend_space = 10) {
    # Author: Brian C. Monsell (OEUS) Version 6.3, 2/10/2026
    
    # check if a value is specified for \code{seas_obj}
    if (is.null(seas_obj)) {
        cat("must specify a seas object")
		return(NULL)
    } else {
    # check if a seas object is specified for \code{seas_obj}
        if (!inherits(seas_obj, "seas")) {
            cat("First argument must be a seas object")
			return(NULL)
        }
    }
    
    # Initialize t-statistic data, point labels
    this_fts <- seasonal::series(seas_obj, "fts")
    point_lab <- substr(dimnames(this_fts)[[2]], 3, 4)
    
    # include identified outliers in plot
    if (add_identified_outliers) {
		this_fts <- update_fts(seas_obj)
    }
    
    # get subset of t-statistics if starting date is specified
    if (!is.null(start_plot)) {
        this_fts <- window(this_fts, start = start_plot)
    }
    
    # if color_otl is NULL, set colors from this_palette
    if (is.null(color_otl)) {
        color_otl <- RColorBrewer::brewer.pal(3, this_palette)[1:length(point_lab)]
    }
    
    # get absolute maximum value of t-statistics, Maximum Position of each column of the Matrix
    fts_max <- 
	    ts(apply(this_fts, 1, absmax), start = start(this_fts), 
	       frequency = frequency(this_fts))
    fts_index <- cbind(time(this_fts), max.col(abs(this_fts), "first"))
    
    # initialize color vector for outlier points
    color_vec <- array(" ", length(point_lab))
    
    # get critical values for outlier identification
    this_crit_vec <- array(0, length(point_lab))
    for (i in 1:length(point_lab)) {
        if (point_lab[i] == "AO") {
            this_crit <- seasonal::udg(seas_obj, "aocrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            color_vec[i] <- color_otl[1]
        }
        if (point_lab[i] == "LS") {
            this_crit <- seasonal::udg(seas_obj, "lscrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            color_vec[i] <- color_otl[2]
        }
        if (point_lab[i] == "TC") {
            this_crit <- seasonal::udg(seas_obj, "tccrit")
            if (length(this_crit) > 0) {
                this_crit_vec[i] <- as.numeric(this_crit[1])
            }
            color_vec[i] <- color_otl[3]
        }
    }
    
    if (length(unique(this_crit_vec)) == 1) {
        sub_title <- 
            paste("Critical Value = ", format(unique(this_crit_vec), decimals = 3), sep = "")
    } else {
        sub_title <- 
            paste("Critical Values = (", paste(format(this_crit_vec, decimals = 3), collapse = " "), ")", sep = " ")
    }
	
	this_data <- 
	    data.frame(date    = tsbox::ts_df(this_fts[,1])$time,
		       fts     = fts_max,
		       outlier = point_lab[fts_index[,2]])
				   
	p_fts <- 
		ggplot2::ggplot(this_data) + 
		ggplot2::geom_point(ggplot2::aes(x = .data$date, 
		                                 y = .data$fts, 
		                                 color = .data$outlier)) + 
		ggplot2::scale_color_manual(labels = point_lab, values = color_vec) +
		ggplot2::labs(title = main_title,
		              subtitle = sub_title,
		              x = this_x_label,
		              y = this_y_label) +
		ggplot2::ylim(range(fts_max, this_crit_vec))
    
    # lines for outlier critical values
    if (length(unique(this_crit_vec)) == 1) {
        p_fts <- 
			p_fts + ggplot2::geom_hline(yintercept = unique(this_crit_vec), color = "grey")
    } else {
		for (i in 1:length(this_crit_vec)) {
			p_fts <- 
				p_fts + ggplot2::geom_hline(yintercept = this_crit_vec[i], color = color_vec[i])
		}
    }
	
	# remove grey background if \code{do_background = FALSE} 
    if (!do_background) {
		p_fts <- p_fts + ggplot2::theme_bw()
    }

	# remove grid lines if \code{do_grid = FALSE}
	if (!do_grid) {
	    p_fts <- p_fts + 
		    ggplot2::theme(panel.grid.major = ggplot2::element_blank(), 
			               panel.grid.minor = ggplot2::element_blank())
	}
    
	p_fts <- p_fts + 
		ggplot2::guides(colour = ggplot2::guide_legend(this_legend_title)) +
		ggplot2::theme(legend.text = ggplot2::element_text(size = this_legend_text_size),
			legend.title = ggplot2::element_text(size = this_legend_title_size),
			legend.position = this_legend_position,
			legend.box.spacing = ggplot2::unit(this_legend_space, "pt"))
	
	return(p_fts)
        
}
