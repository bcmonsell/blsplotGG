#' Retail sales of shoes, 2008
#'
#' A time series object containing retail sales of shoes 
#'
#' @format Retail sales of shoes ending in April of 2008
"shoes2008"
